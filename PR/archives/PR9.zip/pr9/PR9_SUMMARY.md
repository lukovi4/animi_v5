# PR9: Track Mattes (alpha/luma) + Offscreen Matte Pipeline

## Overview
This PR implements track matte support with scope-based rendering architecture.
Supports all 4 Lottie matte modes: alpha, alphaInverted, luma, lumaInverted.

## Files Modified

### Source Files
1. **RenderCommand.swift** - Added `RenderMatteMode` enum and scope-based `beginMatte/endMatte` commands
2. **AnimIR.swift** - Scope-based matte generation with `emitMatteScope`
3. **MetalRenderer+Execute.swift** - 3-pass matte rendering with `extractMatteScope`, `renderMatteScope`, `compositeWithMatte`
4. **MetalRendererResources.swift** - Added matte composite shader with luma support
5. **ShapeCache.swift** - New file for caching rasterized shape textures (matte sources)
6. **MetalRenderer.swift** - Added `shapeCache` property
7. **RenderIssue.swift** - Added `codeMatteSourceNotFound` error code

### Test Files
8. **MetalRendererMatteTests.swift** - New comprehensive test suite (8 tests)
9. **RenderGraphContractTests.swift** - Updated for new matte command format

## Architecture

### Matte Scope Structure
```
beginMatte(mode: .alpha)
  beginGroup(name: "matteSource")
    [source layer commands]
  endGroup
  beginGroup(name: "matteConsumer")
    [consumer layer commands]
  endGroup
endMatte
```

### 3-Pass Rendering Algorithm
1. Render matte source to `matteTex` (offscreen)
2. Render consumer to `consumerTex` (offscreen)
3. Composite using shader: `result.a = consumer.a * matte_factor`

### Matte Modes
- **alpha**: Uses matte source alpha channel
- **alphaInverted**: Uses inverted alpha (1 - alpha)
- **luma**: Uses luminance (0.2126*R + 0.7152*G + 0.0722*B)
- **lumaInverted**: Uses inverted luminance

## Test Results
- All 245 tests pass
- SwiftLint: No errors or warnings on PR9 files

## Key Features
- State inheritance (transform/clip) for matte scopes
- Shape layer support as matte sources via CPU rasterization
- Premultiplied alpha blending throughout pipeline
- Proper error handling for malformed matte scopes
