# TVE Engine — Аудит поддержки Scene.json и Lottie (Anim-x.json)

**Роль:** Технический лидер  \
**Область:** Scene.json Spec v0.1 + Anim-x.json (Lottie / Bodymovin)  \
**Цель:** определить, что *фактически поддерживается end-to-end* по сравнению с тем, *что требуется по спеке*, выявить критические пробелы и зафиксировать действия, которые нужно сделать в первую очередь.

---

## 0. Executive Summary

Текущая кодовая база реализует прочный **фундамент шаблонного видеоредактора** со следующими сильными сторонами:

- детерминированный рендер
- нативный Metal-пайплайн
- реальная поддержка масок и track matte
- строгая философия валидации (fail-fast)

При этом **соответствие Scene.json спеке неполное**, а **поддержка Lottie намеренно ограничена**. Это допустимо *только если ограничения чётко задокументированы и строго enforced в коде*.

### Критические выводы

🔥 **Проблемы Scene.json (обязательно фиксить сейчас)**

- политики длительности и loop для `variant` игнорируются в рантайме
- `emptyPolicy` и контроль активного media source не реализованы
- `background` из scene.json никогда не рендерится
- `containerClip = slotRectAfterSettle` отклоняется валидатором
- zip-формат ScenePackage не поддерживается

🔥 **Риски импорта Lottie**

- Text и Solid слои полностью не поддерживаются (частый кейс в AE-шаблонах)
- поддержка shape-элементов шире, чем задокументировано, но источники валидации рассинхронизированы
- shape layers трактуются неоднозначно: как matte-only

👉 Без фиксов дизайнеры могут создавать **валидные сцены, которые рендерятся некорректно или ломаются молча**.

---

## 1. Scene.json Spec v0.1 — аудит соответствия

**Источник истины:** `scene_json_spec_v_0.md`

### 1.1 Canvas и глобальные параметры сцены

| Фича | Спека | Код | Статус | Комментарий |
|------|-------|-----|--------|-------------|
| schemaVersion | MUST | Валидируется | ✅ | Строгая проверка |
| canvas (size/fps/duration) | MUST | Поддержано | ✅ | Используется в render plan |
| background | optional | Игнорируется | ❌ | Модель есть, рендер отсутствует |

---

### 1.2 MediaBlocks

| Фича | Спека | Код | Статус | Комментарий |
|------|-------|-----|--------|-------------|
| 1..N блоков | MUST | Поддержано | ✅ | Без ограничений |
| rect (canvas coords) | MUST | Поддержано | ✅ | Валидируется |
| сортировка по zIndex | MUST | Поддержано | ✅ | Stable sort |
| timing.start/end | MUST | Поддержано | ✅ | Используется |

---

### 1.3 containerClip

| Значение | Спека | Код | Статус | Комментарий |
|---------|-------|-----|--------|-------------|
| none | allowed | Поддержано | ✅ | |
| slotRect | allowed | Поддержано | ✅ | |
| slotRectAfterSettle | allowed | ❌ Валидатор отклоняет | 🔥 FIX | В рантайме ведёт себя как slotRect |

**Фикс:** разрешить `slotRectAfterSettle` в валидаторе; логировать warning, если семантика settle ещё не реализована.

---

### 1.4 Input и media policy

| Фича | Спека | Код | Статус | Комментарий |
|------|-------|-----|--------|-------------|
| bindingKey | MUST | Enforced | ✅ | Через AnimValidator |
| allowedMedia (union) | MUST | Валидируется | ⚠️ | Не enforced в рантайме |
| ровно один активный source | MUST | ❌ | 🔥 FIX | Нет enforcement |
| emptyPolicy | MUST | ❌ | 🔥 FIX | Не реализовано |

---

### 1.5 Variants и политики тайминга

| Фича | Спека | Код | Статус | Комментарий |
|------|-------|-----|--------|-------------|
| defaultDurationFrames | optional | Игнорируется | ❌ | |
| ifAnimationShorter | MUST | Игнорируется | ❌ | |
| ifAnimationLonger | MUST | Игнорируется | ❌ | |
| loop / loopRange | optional | Игнорируется | ❌ | |

**Текущее поведение:** clamp по границам анимации.  \
**Поведение по спеке:** явные политики.

🔥 **Необходим фикс в `SceneRenderPlan.computeLocalFrameIndex()`**

---

## 2. Anim-x.json / Lottie (Bodymovin) — поддержка

### 2.1 Поддерживаемые типы слоёв (`ty`)

| Тип слоя | ty | Поддержка | Комментарий |
|---------|----|-----------|-------------|
| Image | 2 | ✅ | Основной media |
| Precomp | 0 | ✅ | Вложенные композиции |
| Null | 3 | ✅ | Только трансформы |
| Shape | 4 | ⚠️ | В основном matte / mask |
| Solid | 1 | ❌ | Не поддерживается |
| Text | 5 | ❌ | Не поддерживается |

---

### 2.2 Трансформы (`ks`)

| Фича | Поддержка | Комментарий |
|------|-----------|-------------|
| position / scale / rotation / opacity | ✅ | Анимируемые |
| anchor point | ✅ | Корректно |
| skew / skewAxis | ❌ | Ошибка валидатора |
| 3D слои (ddd) | ❌ | Явная ошибка |
| auto-orient (ao) | ❌ | Явная ошибка |

---

### 2.3 Masks

| Фича | Поддержка | Комментарий |
|------|-----------|-------------|
| Mask path | ✅ | Статические и анимированные |
| Топология анимированного пути | ✅ | Строгая валидация |
| Inverted masks | ✅ | |
| Режимы (add/sub/intersect) | ✅ | Только a/s/i |
| Expansion | ❌ | Должен быть 0 |

---

### 2.4 Track Mattes

| Фича | Поддержка | Комментарий |
|------|-----------|-------------|
| Alpha / AlphaInv | ✅ | |
| Luma / LumaInv | ✅ | |
| Nested precomp mattes | ⚠️ | Ранее были баги, частично исправлено |

---

## 3. Shape support (ty=4)

### 3.1 Shape items

| Элемент | ty | Поддержка | Комментарий |
|--------|----|-----------|-------------|
| Group | gr | ✅ | Только один transform |
| Path | sh | ✅ | Статичный / анимированный |
| Fill | fl | ✅ | Только solid |
| Stroke | st | ✅ | Width и dash валидируются |
| Rect | rc | ✅ | Roundness только статичный |
| Ellipse | el | ✅ | |
| Polystar | sr | ✅ | |
| Trim Paths | tm | ❌ | Явная ошибка |
| Merge Paths | — | ❌ | Не поддерживается |
| Repeater | — | ❌ | Не поддерживается |
| Gradient Fill/Stroke | — | ❌ | Не поддерживается |

---

### 3.2 Критический баг валидатора

Константа `supportedShapeTypes` содержит только:

```
["gr", "sh", "fl", "tr"]
```

При этом реальный валидатор поддерживает `rc / el / sr / st`.

🔥 **Фикс:** удалить или синхронизировать эту константу, чтобы избежать ложных ошибок.

---

### 3.3 Семантика shape layers (архитектурная неоднозначность)

Сейчас:

- shape компилируются
- пути и stroke существуют
- в рендерере есть `drawShape / drawStroke`

Но:

- shape layers трактуются как **источники масок / matte**, а не как видимая графика

**Требуется решение:**

- Вариант A: явно запретить видимые shape layers (и задокументировать)
- Вариант B: сделать shapes полноценными видимыми слоями

Оставлять это неоднозначным — опасно.

---

## 4. Риски на стыке Scene × Lottie

| Кейс | Ожидание | Факт | Риск |
|------|----------|------|------|
| variant короче сцены | policy-based | clamp | High |
| пустой блок + hideWholeBlock | skip | рендерится | High |
| background color | видим | отсутствует | Medium |
| slotRectAfterSettle | отложенный clip | немедленный | Medium |
| nested matte в precomp | корректно | хрупко | Medium |

---

## 5. Fix-Now backlog (уровень PR)

| Приоритет | PR | Описание |
|----------|----|----------|
| 🔥 | PR-01 | SceneValidator: разрешить slotRectAfterSettle |
| 🔥 | PR-02 | SceneRenderPlan: политики длительности и loop для variant |
| 🔥 | PR-03 | ScenePlayer: emptyPolicy и enforcement активного media |
| 🔥 | PR-04 | RenderPlan: рендер background |
| 🔥 | PR-05 | ScenePackageLoader: поддержка zip |
| 🔥 | PR-06 | AnimValidator: фикc supportedShapeTypes |
| ⚠️ | PR-07 | Определить и зафиксировать семантику shape layers |

---

## 6. Render / Metal — корректность

### 6.1 Masks (GPU mask pipeline)

**Текущее состояние**

- Маски рендерятся через GPU coverage textures (`r8Unorm`) + compute kernel.
- Поддерживаются boolean-режимы: add / subtract / intersect.
- Анимированные mask paths валидируются по топологии.

**Риски корректности**

- Fill rule не зафиксирован явно (triangulation-based); должен совпадать с AE non-zero.
- Нет anti-aliasing на краях масок → возможны «лесенки».

**Fix-now**

- Явно зафиксировать fill rule.
- Добавить AA для масок (минимум для export path).
- Добавить тесты сравнения CPU vs GPU масок.

---

### 6.2 Track Mattes (Alpha / Luma)

**Текущее состояние**

- Поддерживаются Alpha / AlphaInv / Luma / LumaInv.
- Реализация через offscreen textures и composite shader.

**Риски корректности**

- Luma зависит от цветового пространства (sRGB vs linear).
- Требуется строгий premultiplied alpha для всех источников.

**Fix-now**

- Enforce premultiplied alpha для image/video пайплайнов.
- Добавить golden-tests для alpha и luma mattes.

---

### 6.3 Precomp transforms и вложенность

**Текущее состояние**

- Parent transforms поддержаны.
- Nested precomps + masks исторически хрупкое место.

**Риски корректности**

- Двойное применение или потеря parent transform.
- Маски/mattes рендерятся не в тех координатах.

**Fix-now**

- Определить единый source-of-truth для transform propagation.
- Добавить smoke-tests: несколько блоков + nested precomp + mask.

---

### 6.4 Clipping (Scissor / Mask)

**Текущее состояние**

- Прямоугольный clip — через Metal scissor.
- Сложный clip — через mask textures.

**Риски корректности**

- Ошибки округления в пикселях (1px leaks) на scale 2x/3x.

**Fix-now**

- Стандартизировать политику округления rect → scissor.
- Добавить regression-тесты для разных scale.

---

### 6.5 Blending и alpha

**Текущее состояние**

- Premultiplied alpha blending настроен корректно.

**Риски корректности**

- Straight-alpha источники дадут ореолы.

**Fix-now**

- Принудительно конвертировать или запретить straight-alpha текстуры.
- Добавить edge-case тесты для PNG.

---

## 7. Performance & Caching

### 7.1 Сильные стороны

- TexturePool с переиспользованием
- Кеши shape и path
- Ring buffer для vertex upload
- PerfMetrics для профилирования

---

### 7.2 Рост памяти

**Проблема**

- У TexturePool нет глобального лимита памяти.

**Fix-now**

- Ввести лимит на общий объём памяти + LRU eviction.
- Ограничить количество текстур на ключ.

---

### 7.3 Детерминизм кешей

**Риск**

- Ключи кешей зависят от float → возможны промахи.

**Fix-now**

- Квантизировать float перед хешированием.

---

### 7.4 Export path

**Риск**

- Длинные экспорт-сессии могут бесконтрольно раздувать кеши.

**Fix-now**

- Добавить lifecycle: `beginExportSession / endExportSession`.
- Сбрасывать или ограничивать кеши на экспорт.

---

### 7.5 Метрики и мониторинг

**Fix-now**

- Добавить memory-счётчики в PerfMetrics:
  - pooled bytes
  - offscreen peak bytes
  - texture count

---

## 8. Fix-Now backlog (финальный)

| Приоритет | PR | Описание |
|----------|----|----------|
| 🔥 | PR-01 | SceneValidator: разрешить slotRectAfterSettle |
| 🔥 | PR-02 | SceneRenderPlan: политики тайминга и loop |
| 🔥 | PR-03 | ScenePlayer: emptyPolicy и active media enforcement |
| 🔥 | PR-04 | RenderPlan: рендер background |
| 🔥 | PR-05 | ScenePackageLoader: поддержка zip |
| 🔥 | PR-06 | AnimValidator: исправить supportedShapeTypes |
| 🔥 | PR-07 | Enforce premultiplied alpha pipeline |
| 🔥 | PR-08 | TexturePool: лимиты памяти + LRU |
| ⚠️ | PR-09 | Anti-aliasing для масок |
| ⚠️ | PR-10 | Lifecycle export-сессии |

---

## 9. Финальный вердикт

Архитектура движка **в целом production-capable**, но **пока не production-safe** без выполнения пунктов выше.

После закрытия 🔥 Fix-Now backlog система:

- корректно воспроизводит семантику Scene.json
- корректно рендерит AE masks / mattes / precomps
- остаётся детерминированной и безопасной по памяти при playback и export

Документ **готов к передаче команде разработки** как авторитетный чеклист реализации.

