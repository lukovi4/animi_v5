import Foundation

// MARK: - Bezier Path

/// Render-agnostic bezier path representation
public struct BezierPath: Sendable, Equatable {
    /// Path vertices (control points)
    public let vertices: [Vec2D]

    /// In tangents (relative to vertex)
    public let inTangents: [Vec2D]

    /// Out tangents (relative to vertex)
    public let outTangents: [Vec2D]

    /// Whether the path is closed
    public let closed: Bool

    public init(vertices: [Vec2D], inTangents: [Vec2D], outTangents: [Vec2D], closed: Bool) {
        self.vertices = vertices
        self.inTangents = inTangents
        self.outTangents = outTangents
        self.closed = closed
    }

    /// Creates an empty path
    public static let empty = Self(vertices: [], inTangents: [], outTangents: [], closed: false)

    /// Number of vertices in the path
    public var vertexCount: Int {
        vertices.count
    }

    /// Returns true if the path has no vertices
    public var isEmpty: Bool {
        vertices.isEmpty
    }

    /// Axis-aligned bounding box of the path vertices (minX, minY, maxX, maxY)
    public var aabb: (minX: Double, minY: Double, maxX: Double, maxY: Double) { // swiftlint:disable:this large_tuple
        guard !vertices.isEmpty else {
            return (0, 0, 0, 0)
        }
        var minX = vertices[0].x
        var minY = vertices[0].y
        var maxX = vertices[0].x
        var maxY = vertices[0].y
        for vertex in vertices.dropFirst() {
            minX = min(minX, vertex.x)
            minY = min(minY, vertex.y)
            maxX = max(maxX, vertex.x)
            maxY = max(maxY, vertex.y)
        }
        return (minX, minY, maxX, maxY)
    }

    /// Returns a new path with all vertices and tangents transformed by the given matrix
    public func applying(_ matrix: Matrix2D) -> BezierPath {
        // If identity matrix, return self unchanged
        if matrix == .identity {
            return self
        }

        let transformedVertices = vertices.map { matrix.apply(to: $0) }
        let transformedInTangents = inTangents.map { matrix.applyToVector($0) }
        let transformedOutTangents = outTangents.map { matrix.applyToVector($0) }

        return BezierPath(
            vertices: transformedVertices,
            inTangents: transformedInTangents,
            outTangents: transformedOutTangents,
            closed: closed
        )
    }
}

// MARK: - BezierPath from Lottie

extension BezierPath {
    /// Creates BezierPath from LottiePathData
    public init?(from pathData: LottiePathData?) {
        guard let pathData = pathData,
              let vertices = pathData.vertices,
              !vertices.isEmpty else {
            return nil
        }

        self.vertices = vertices.map { arr in
            Vec2D(x: !arr.isEmpty ? arr[0] : 0, y: arr.count > 1 ? arr[1] : 0)
        }

        self.inTangents = (pathData.inTangents ?? []).map { arr in
            Vec2D(x: !arr.isEmpty ? arr[0] : 0, y: arr.count > 1 ? arr[1] : 0)
        }

        self.outTangents = (pathData.outTangents ?? []).map { arr in
            Vec2D(x: !arr.isEmpty ? arr[0] : 0, y: arr.count > 1 ? arr[1] : 0)
        }

        self.closed = pathData.closed ?? false
    }

    /// Creates BezierPath from LottieAnimatedValue (expects static path)
    public init?(from animatedValue: LottieAnimatedValue?) {
        guard let animatedValue = animatedValue,
              let data = animatedValue.value else {
            return nil
        }

        switch data {
        case .path(let pathData):
            self.init(from: pathData)
        default:
            return nil
        }
    }
}

// MARK: - Animated Path

/// Path that can be static or animated
public enum AnimPath: Sendable, Equatable {
    /// Static (non-animated) bezier path
    case staticBezier(BezierPath)

    /// Keyframed bezier path animation (reserved for future use)
    case keyframedBezier([Keyframe<BezierPath>])

    /// Returns the static path or first keyframe value
    public var staticPath: BezierPath? {
        switch self {
        case .staticBezier(let path):
            return path
        case .keyframedBezier(let keyframes):
            return keyframes.first?.value
        }
    }

    /// Returns true if this path is animated
    public var isAnimated: Bool {
        switch self {
        case .staticBezier:
            return false
        case .keyframedBezier(let keyframes):
            return keyframes.count > 1
        }
    }
}

// MARK: - Mask

/// IR representation of a layer mask
public struct Mask: Sendable, Equatable {
    /// Mask mode (only .add supported in Part 1)
    public let mode: MaskMode

    /// Inverted flag
    public let inverted: Bool

    /// Mask opacity (0-100)
    public let opacity: Double

    /// Mask path
    public let path: AnimPath

    public init(mode: MaskMode, inverted: Bool, opacity: Double, path: AnimPath) {
        self.mode = mode
        self.inverted = inverted
        self.opacity = opacity
        self.path = path
    }
}

// MARK: - Mask from Lottie

extension Mask {
    /// Creates Mask from LottieMask
    public init?(from lottieMask: LottieMask) {
        // Mode must be "a" (add) for Part 1
        guard let mode = MaskMode(lottieMode: lottieMask.mode) else {
            return nil
        }
        self.mode = mode

        self.inverted = lottieMask.inverted ?? false

        // Extract opacity (static only in Part 1)
        if let opacityValue = lottieMask.opacity,
           let data = opacityValue.value {
            switch data {
            case .number(let num):
                self.opacity = num
            case .array(let arr) where !arr.isEmpty:
                self.opacity = arr[0]
            default:
                self.opacity = 100
            }
        } else {
            self.opacity = 100
        }

        // Extract path
        guard let pathValue = lottieMask.path else {
            return nil
        }

        if pathValue.isAnimated {
            // Animated paths - extract keyframes (for future use, currently validated against in PR3)
            guard let data = pathValue.value,
                  case .keyframes(let kfs) = data else {
                return nil
            }

            // For now, just use first keyframe as static (PR3 validates no animated paths)
            if let firstPath = kfs.first,
               let startValue = firstPath.startValue {
                // Reconstruct path data from keyframe
                let pathData = LottiePathData(
                    inTangents: nil,
                    outTangents: nil,
                    vertices: [startValue],
                    closed: true
                )
                if let bezier = BezierPath(from: pathData) {
                    self.path = .staticBezier(bezier)
                } else {
                    return nil
                }
            } else {
                return nil
            }
        } else {
            // Static path
            guard let bezier = BezierPath(from: pathValue) else {
                return nil
            }
            self.path = .staticBezier(bezier)
        }
    }
}

// MARK: - Shape Path Extraction

/// Extracts bezier path from shape layer shapes
public enum ShapePathExtractor {
    /// Extracts the first path from a list of Lottie shapes
    public static func extractPath(from shapes: [ShapeItem]?) -> BezierPath? {
        guard let shapes = shapes else { return nil }

        for shape in shapes {
            if let path = extractPathFromShape(shape) {
                return path
            }
        }
        return nil
    }

    private static func extractPathFromShape(_ shape: ShapeItem) -> BezierPath? {
        switch shape {
        case .path(let pathShape):
            // Path shape - extract vertices
            return BezierPath(from: pathShape.vertices)

        case .group(let shapeGroup):
            // Group - recurse into items and apply group transform
            guard let items = shapeGroup.items else { return nil }

            // 1) Extract group transform matrix from tr element (identity if absent)
            let groupMatrix = extractGroupTransformMatrix(from: items)

            // 2) Extract path from items (recursive)
            guard let path = extractPath(from: items) else { return nil }

            // 3) Apply group matrix to path vertices and tangents
            return path.applying(groupMatrix)

        default:
            return nil
        }
    }

    /// Extracts transform matrix from group items (ty="tr")
    /// Formula: T(position) * R(rotation) * S(scale) * T(-anchor)
    /// Returns identity if no transform found
    private static func extractGroupTransformMatrix(from items: [ShapeItem]) -> Matrix2D {
        // Find transform item in group
        let transformItem = items.compactMap { item -> LottieShapeTransform? in
            if case .transform(let transform) = item { return transform }
            return nil
        }.first

        guard let transform = transformItem else {
            return .identity
        }

        // Extract static values (animated values not supported for group transform in Part 1)
        let position = extractVec2D(from: transform.position) ?? Vec2D(x: 0, y: 0)
        let anchor = extractVec2D(from: transform.anchor) ?? Vec2D(x: 0, y: 0)
        let scale = extractVec2D(from: transform.scale) ?? Vec2D(x: 100, y: 100)
        let rotation = extractDouble(from: transform.rotation) ?? 0

        // Normalize scale from percentage (100 = 1.0)
        let scaleX = scale.x / 100.0
        let scaleY = scale.y / 100.0

        // Build matrix: T(position) * R(rotation) * S(scale) * T(-anchor)
        return Matrix2D.translation(x: position.x, y: position.y)
            .concatenating(.rotationDegrees(rotation))
            .concatenating(.scale(x: scaleX, y: scaleY))
            .concatenating(.translation(x: -anchor.x, y: -anchor.y))
    }

    /// Extracts Vec2D from LottieAnimatedValue (static only)
    private static func extractVec2D(from value: LottieAnimatedValue?) -> Vec2D? {
        guard let value = value, let data = value.value else { return nil }
        switch data {
        case .array(let arr) where arr.count >= 2:
            return Vec2D(x: arr[0], y: arr[1])
        default:
            return nil
        }
    }

    /// Extracts Double from LottieAnimatedValue (static only)
    private static func extractDouble(from value: LottieAnimatedValue?) -> Double? {
        guard let value = value, let data = value.value else { return nil }
        switch data {
        case .number(let num):
            return num
        case .array(let arr) where !arr.isEmpty:
            return arr[0]
        default:
            return nil
        }
    }

    /// Extracts fill color from shape layer shapes
    public static func extractFillColor(from shapes: [ShapeItem]?) -> [Double]? {
        guard let shapes = shapes else { return nil }

        for shape in shapes {
            if let color = extractFillFromShape(shape) {
                return color
            }
        }
        return nil
    }

    private static func extractFillFromShape(_ shape: ShapeItem) -> [Double]? {
        switch shape {
        case .fill(let fill):
            // Fill shape - extract color
            guard let colorValue = fill.color,
                  let data = colorValue.value,
                  case .array(let arr) = data else {
                return nil
            }
            return arr

        case .group(let shapeGroup):
            // Group - recurse into items
            guard let items = shapeGroup.items else { return nil }
            return extractFillColor(from: items)

        default:
            return nil
        }
    }

    /// Extracts fill opacity from shape layer shapes
    public static func extractFillOpacity(from shapes: [ShapeItem]?) -> Double {
        guard let shapes = shapes else { return 100 }

        for shape in shapes {
            if let opacity = extractFillOpacityFromShape(shape) {
                return opacity
            }
        }
        return 100
    }

    private static func extractFillOpacityFromShape(_ shape: ShapeItem) -> Double? {
        switch shape {
        case .fill(let fill):
            // Fill shape - extract opacity
            guard let opacityValue = fill.opacity,
                  let data = opacityValue.value else {
                return nil
            }
            switch data {
            case .number(let num):
                return num
            case .array(let arr) where !arr.isEmpty:
                return arr[0]
            default:
                return nil
            }

        case .group(let shapeGroup):
            // Group - recurse into items
            guard let items = shapeGroup.items else { return nil }
            return extractFillOpacity(from: items)

        default:
            return nil
        }
    }
}
