import XCTest
@testable import TVECore

final class AnimValidatorTests: XCTestCase {
    private var validator: AnimValidator!
    private var loader: AnimLoader!
    private var packageLoader: ScenePackageLoader!
    private var tempDir: URL!

    override func setUp() {
        super.setUp()
        validator = AnimValidator()
        loader = AnimLoader()
        packageLoader = ScenePackageLoader()
    }

    override func tearDown() {
        if let tempDir = tempDir {
            try? FileManager.default.removeItem(at: tempDir)
        }
        tempDir = nil
        validator = nil
        loader = nil
        packageLoader = nil
        super.tearDown()
    }

    // MARK: - Helper Methods

    private func createTempPackage(
        sceneJSON: String,
        animFiles: [String: String],
        images: [String] = []
    ) throws -> ScenePackage {
        tempDir = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

        let sceneURL = tempDir.appendingPathComponent("scene.json")
        try sceneJSON.write(to: sceneURL, atomically: true, encoding: .utf8)

        for (name, content) in animFiles {
            let url = tempDir.appendingPathComponent(name)
            try content.write(to: url, atomically: true, encoding: .utf8)
        }

        if !images.isEmpty {
            let imagesDir = tempDir.appendingPathComponent("images")
            try FileManager.default.createDirectory(at: imagesDir, withIntermediateDirectories: true)
            for imageName in images {
                let imageURL = imagesDir.appendingPathComponent(imageName)
                try Data([0x89, 0x50, 0x4E, 0x47]).write(to: imageURL)
            }
        }

        return try packageLoader.load(from: tempDir)
    }

    private func sceneJSON(
        fps: Int = 30,
        inputWidth: Double = 540,
        inputHeight: Double = 960,
        bindingKey: String = "media",
        animRef: String = "anim-1.json"
    ) -> String {
        """
        {
          "schemaVersion": "0.1",
          "canvas": { "width": 1080, "height": 1920, "fps": \(fps), "durationFrames": 300 },
          "mediaBlocks": [{
            "blockId": "block_01",
            "zIndex": 0,
            "rect": { "x": 0, "y": 0, "width": 540, "height": 960 },
            "containerClip": "slotRect",
            "input": {
              "rect": { "x": 0, "y": 0, "width": \(inputWidth), "height": \(inputHeight) },
              "bindingKey": "\(bindingKey)",
              "allowedMedia": ["photo"]
            },
            "variants": [{ "variantId": "v1", "animRef": "\(animRef)" }]
          }]
        }
        """
    }

    private func animJSON(
        width: Int = 1080,
        height: Int = 1920,
        frameRate: Int = 30,
        inPoint: Int = 0,
        outPoint: Int = 300,
        bindingLayerName: String = "media",
        bindingLayerType: Int = 2,
        bindingRefId: String? = "image_0",
        imageFile: String = "img_1.png",
        includeImage: Bool = true,
        extraLayers: String = "",
        extraAssets: String = "",
        masksJSON: String = "",
        shapesJSON: String = "",
        trackMatteType: Int? = nil,
        matteSource: Int? = nil
    ) -> String {
        let refIdPart = bindingRefId.map { "\"refId\": \"\($0)\"," } ?? ""
        let ttPart = trackMatteType.map { "\"tt\": \($0)," } ?? ""
        let tdPart = matteSource.map { "\"td\": \($0)," } ?? ""
        let masksPart = masksJSON.isEmpty ? "" : "\"hasMask\": true, \"masksProperties\": [\(masksJSON)],"
        let shapesPart = shapesJSON.isEmpty ? "" : "\"shapes\": [\(shapesJSON)],"

        let imageAsset = includeImage
            ? "{ \"id\": \"image_0\", \"w\": 540, \"h\": 960, \"u\": \"images/\", \"p\": \"\(imageFile)\", \"e\": 0 },"
            : ""

        return """
        {
          "v": "5.12.1",
          "fr": \(frameRate),
          "ip": \(inPoint),
          "op": \(outPoint),
          "w": \(width),
          "h": \(height),
          "nm": "Test",
          "ddd": 0,
          "assets": [
            \(imageAsset)
            { "id": "comp_0", "nm": "precomp", "fr": 30,
              "layers": [
                {
                  "ty": 4, "ind": 99, "nm": "mediaInput", "hd": true,
                  "shapes": [{ "ty": "gr", "it": [
                    { "ty": "sh", "ks": { "a": 0, "k": {
                      "v": [[0,0],[100,0],[100,100],[0,100]],
                      "i": [[0,0],[0,0],[0,0],[0,0]],
                      "o": [[0,0],[0,0],[0,0],[0,0]],
                      "c": true
                    }}},
                    { "ty": "fl", "c": { "a": 0, "k": [0,0,0,1] }, "o": { "a": 0, "k": 100 } }
                  ]}],
                  "ks": { "o": { "a": 0, "k": 100 }, "r": { "a": 0, "k": 0 },
                          "p": { "a": 0, "k": [0,0,0] }, "a": { "a": 0, "k": [0,0,0] },
                          "s": { "a": 0, "k": [100,100,100] } },
                  "ip": 0, "op": 300, "st": 0
                },
                {
                  "ty": \(bindingLayerType),
                  "nm": "\(bindingLayerName)",
                  \(refIdPart)
                  "ind": 1
                }
              ]
            }
            \(extraAssets)
          ],
          "layers": [
            {
              "ty": 0,
              "nm": "precomp_layer",
              "refId": "comp_0",
              "ind": 1,
              "ip": 0,
              "op": 300,
              \(masksPart)
              \(ttPart)
              \(tdPart)
              \(shapesPart)
              "ks": { "o": { "a": 0, "k": 100 } }
            }
            \(extraLayers)
          ]
        }
        """
    }

    private func validatePackage(
        sceneJSON: String,
        animJSON: String,
        animRef: String = "anim-1.json",
        images: [String] = ["img_1.png"],
        options: AnimValidator.Options? = nil
    ) throws -> ValidationReport {
        let package = try createTempPackage(
            sceneJSON: sceneJSON,
            animFiles: [animRef: animJSON],
            images: images
        )
        let loaded = try loader.loadAnimations(from: package)
        let validatorToUse: AnimValidator = options.map { AnimValidator(options: $0) } ?? validator
        return validatorToUse.validate(scene: package.scene, package: package, loaded: loaded)
    }

    // MARK: - Happy Path Tests

    func testValidate_validAnim_noErrors() throws {
        let scene = sceneJSON(inputWidth: 1080, inputHeight: 1920)
        let anim = animJSON()
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        XCTAssertFalse(report.hasErrors)
        XCTAssertEqual(report.errors.count, 0)
    }

    func testValidate_sizeMismatch_returnsWarning() throws {
        let scene = sceneJSON(inputWidth: 540, inputHeight: 960)
        let anim = animJSON(width: 1080, height: 1920)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let warning = report.warnings.first {
            $0.code == AnimValidationCode.warningAnimSizeMismatch
        }
        XCTAssertNotNil(warning)
        XCTAssertTrue(warning?.message.contains("1080x1920") ?? false)
        XCTAssertTrue(warning?.message.contains("540x960") ?? false)
    }

    // MARK: - FPS Mismatch Tests

    func testValidate_fpsMismatch_returnsError() throws {
        let scene = sceneJSON(fps: 30)
        let anim = animJSON(frameRate: 25)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.animFPSMismatch
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains("anim(anim-1.json).fr") ?? false)
        XCTAssertTrue(error?.message.contains("fps=30") ?? false)
        XCTAssertTrue(error?.message.contains("fr=25") ?? false)
    }

    // MARK: - Root Sanity Tests

    func testValidate_invalidWidth_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(width: 0)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.animRootInvalid && $0.path.contains(".w")
        }
        XCTAssertNotNil(error)
    }

    func testValidate_invalidHeight_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(height: -100)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.animRootInvalid && $0.path.contains(".h")
        }
        XCTAssertNotNil(error)
    }

    func testValidate_invalidFrameRate_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(frameRate: 0)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.animRootInvalid && $0.path.contains(".fr")
        }
        XCTAssertNotNil(error)
    }

    func testValidate_invalidDuration_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(inPoint: 100, outPoint: 50)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.animRootInvalid && $0.path.contains(".op")
        }
        XCTAssertNotNil(error)
    }

    // MARK: - Binding Layer Tests

    func testValidate_bindingLayerNotFound_returnsError() throws {
        let scene = sceneJSON(bindingKey: "user_photo")
        let anim = animJSON(bindingLayerName: "media")
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.bindingLayerNotFound
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("user_photo") ?? false)
    }

    func testValidate_bindingLayerAmbiguous_returnsError() throws {
        let scene = sceneJSON(bindingKey: "media")
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [
              { "ty": 2, "nm": "media", "refId": "image_0" },
              { "ty": 2, "nm": "media", "refId": "image_0" }
            ]}
          ],
          "layers": [{ "ty": 0, "refId": "comp_0" }]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.bindingLayerAmbiguous
        }
        XCTAssertNotNil(error)
    }

    func testValidate_bindingLayerNotImage_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(bindingLayerType: 3) // null layer
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.bindingLayerNotImage
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("ty=3") ?? false)
    }

    func testValidate_bindingLayerNoAsset_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(bindingRefId: nil)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.bindingLayerNoAsset
        }
        XCTAssertNotNil(error)
    }

    // MARK: - Asset Missing Tests

    func testValidate_assetMissing_returnsError() throws {
        let scene = sceneJSON()
        let anim = animJSON(imageFile: "missing.png")
        let report = try validatePackage(sceneJSON: scene, animJSON: anim, images: [])

        let error = report.errors.first {
            $0.code == AnimValidationCode.assetMissing
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("missing.png") ?? false)
    }

    // MARK: - Precomp Ref Tests

    func testValidate_precompRefMissing_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "missing_comp" }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.precompRefMissing
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("missing_comp") ?? false)
    }

    // MARK: - Unsupported Layer Type Tests

    func testValidate_unsupportedLayerType_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 1, "nm": "solid_layer" }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerType
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("type 1") ?? false)
    }

    // MARK: - Mask Validation Tests

    func testValidate_maskModeSubtract_noError() throws {
        // Subtract mode (s) is now supported
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "s", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskMode
        }
        XCTAssertNil(error, "Subtract mode (s) should be supported")
    }

    func testValidate_maskModeIntersect_noError() throws {
        // Intersect mode (i) is now supported
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "i", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskMode
        }
        XCTAssertNil(error, "Intersect mode (i) should be supported")
    }

    func testValidate_maskModeLighten_returnsError() throws {
        // Lighten mode (l) is NOT supported
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "l", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskMode
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("'l'") ?? false)
        XCTAssertTrue(error?.message.contains("a (add), s (subtract), i (intersect)") ?? false)
    }

    func testValidate_maskModeDarken_returnsError() throws {
        // Darken mode (d) is NOT supported
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "d", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskMode
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("'d'") ?? false)
    }

    func testValidate_maskInverted_noError() throws {
        // Inverted masks are now supported
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": true, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        XCTAssertTrue(report.errors.isEmpty, "Inverted masks should be supported")
    }

    func testValidate_maskPathAnimated_returnsError_whenDisabled() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 1, "k": [] }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        // Explicitly disable animated mask paths to test the error case
        var options = AnimValidator.Options()
        options.allowAnimatedMaskPath = false
        let report = try validatePackage(sceneJSON: scene, animJSON: anim, options: options)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskPathAnimated
        }
        XCTAssertNotNil(error)
    }

    func testValidate_maskPathAnimated_noError_whenEnabled() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 1, "k": [] }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        // Default: allowAnimatedMaskPath = true
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskPathAnimated
        }
        XCTAssertNil(error, "Animated mask paths should be allowed by default")
    }

    func testValidate_maskOpacityAnimated_returnsError() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 1, "k": [] } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskOpacityAnimated
        }
        XCTAssertNotNil(error)
    }

    // MARK: - Mask Expansion Tests

    func testValidate_maskExpansionNonZero_returnsError() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 }, "x": { "a": 0, "k": 10 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskExpansionNonZero
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".x.k") ?? false)
        XCTAssertTrue(error?.message.contains("10") ?? false)
    }

    func testValidate_maskExpansionAnimated_returnsError() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 }, "x": { "a": 1, "k": [{"t": 0, "s": [0]}, {"t": 30, "s": [10]}] } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskExpansionAnimated
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".x.a") ?? false)
    }

    func testValidate_maskExpansionZero_noError() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 }, "x": { "a": 0, "k": 0 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskExpansionNonZero ||
            $0.code == AnimValidationCode.unsupportedMaskExpansionAnimated
        }
        XCTAssertNil(error, "Mask expansion x=0 should be allowed")
    }

    func testValidate_maskExpansionAbsent_noError() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskExpansionNonZero ||
            $0.code == AnimValidationCode.unsupportedMaskExpansionAnimated
        }
        XCTAssertNil(error, "Absent mask expansion should be allowed")
    }

    func testValidate_maskExpansionUnknownFormat_returnsError() throws {
        // Test fail-fast: unknown format (e.g., object instead of number) should error
        let scene = sceneJSON()
        // Using keyframes format for static value - this is an invalid/unexpected format
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 }, "x": { "a": 0, "k": {"invalid": "format"} } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskExpansionFormat
        }
        XCTAssertNotNil(error, "Unknown mask expansion format should produce error (no silent ignore)")
        XCTAssertTrue(error?.path.contains(".x.k") ?? false)
    }

    // MARK: - Track Matte Tests

    func testValidate_unsupportedMatteType_returnsError() throws {
        let scene = sceneJSON()
        // tt=5 is unsupported (only 1-4 are valid)
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "tt": 5 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMatteType
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("type 5") ?? false)
    }

    func testValidate_supportedMatteTypes_noError() throws {
        let scene = sceneJSON()
        // Test all 4 supported matte types: alpha(1), alphaInv(2), luma(3), lumaInv(4)
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 4, "td": 1, "shapes": [{ "ty": "gr", "it": [{ "ty": "sh" }, { "ty": "fl" }] }] },
            { "ty": 0, "refId": "comp_0", "tt": 1 },
            { "ty": 4, "td": 1, "shapes": [{ "ty": "gr", "it": [{ "ty": "sh" }, { "ty": "fl" }] }] },
            { "ty": 0, "refId": "comp_0", "tt": 2 },
            { "ty": 4, "td": 1, "shapes": [{ "ty": "gr", "it": [{ "ty": "sh" }, { "ty": "fl" }] }] },
            { "ty": 0, "refId": "comp_0", "tt": 3 },
            { "ty": 4, "td": 1, "shapes": [{ "ty": "gr", "it": [{ "ty": "sh" }, { "ty": "fl" }] }] },
            { "ty": 0, "refId": "comp_0", "tt": 4 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let matteError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMatteType
        }
        XCTAssertNil(matteError)
    }

    // MARK: - Shape Subset Tests

    func testValidate_unsupportedShapeItem_returnsError() throws {
        // Test with gradient stroke (gs) - which is NOT supported
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 4, "td": 1, "shapes": [{ "ty": "gs", "nm": "Gradient Stroke" }] },
            { "ty": 0, "refId": "comp_0", "tt": 1 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.message.contains("'gs'") ?? false)
    }

    func testValidate_supportedShapeItems_noError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            {
              "ty": 4,
              "td": 1,
              "shapes": [{
                "ty": "gr",
                "it": [
                  { "ty": "sh", "ks": { "a": 0, "k": {} } },
                  { "ty": "fl", "c": { "a": 0, "k": [0, 0, 0, 1] } },
                  { "ty": "tr", "p": { "a": 0, "k": [0, 0] } }
                ]
              }]
            },
            { "ty": 0, "refId": "comp_0", "tt": 1 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let shapeError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem
        }
        XCTAssertNil(shapeError)
    }

    // MARK: - Path Topology Validation Tests

    func testValidate_animatedPathTopologyMismatch_producesValidationError() throws {
        // Create validator with animated paths allowed
        var options = AnimValidator.Options()
        options.allowAnimatedMaskPath = true
        let customValidator = AnimValidator(options: options)

        let scene = sceneJSON()
        // Animated mask with topology mismatch: first keyframe has 4 vertices, second has 3
        let maskJSON = """
        {
          "mode": "a",
          "inv": false,
          "pt": {
            "a": 1,
            "k": [
              {
                "t": 0,
                "s": [{ "v": [[0,0], [100,0], [100,100], [0,100]], "i": [[0,0], [0,0], [0,0], [0,0]], "o": [[0,0], [0,0], [0,0], [0,0]], "c": true }]
              },
              {
                "t": 30,
                "s": [{ "v": [[0,0], [100,0], [100,100]], "i": [[0,0], [0,0], [0,0]], "o": [[0,0], [0,0], [0,0]], "c": true }]
              }
            ]
          },
          "o": { "a": 0, "k": 100 }
        }
        """
        let anim = animJSON(masksJSON: maskJSON)

        let package = try createTempPackage(
            sceneJSON: scene,
            animFiles: ["anim-1.json": anim],
            images: ["img_1.png"]
        )
        let loaded = try loader.loadAnimations(from: package)
        let report = customValidator.validate(scene: package.scene, package: package, loaded: loaded)

        // Should have a topology mismatch error
        let topologyError = report.errors.first {
            $0.code == AnimValidationCode.pathTopologyMismatch
        }
        XCTAssertNotNil(topologyError, "Topology mismatch should produce validation error, not silent nil")
        XCTAssertTrue(topologyError?.message.contains("4") ?? false, "Error should mention expected vertex count")
        XCTAssertTrue(topologyError?.message.contains("3") ?? false, "Error should mention actual vertex count")
    }

    func testValidate_animatedPathTopologyMismatch_closedFlag_producesError() throws {
        // Create validator with animated paths allowed
        var options = AnimValidator.Options()
        options.allowAnimatedMaskPath = true
        let customValidator = AnimValidator(options: options)

        let scene = sceneJSON()
        // Animated mask with closed flag mismatch
        let maskJSON = """
        {
          "mode": "a",
          "inv": false,
          "pt": {
            "a": 1,
            "k": [
              {
                "t": 0,
                "s": [{ "v": [[0,0], [100,0]], "i": [[0,0], [0,0]], "o": [[0,0], [0,0]], "c": true }]
              },
              {
                "t": 30,
                "s": [{ "v": [[0,0], [100,0]], "i": [[0,0], [0,0]], "o": [[0,0], [0,0]], "c": false }]
              }
            ]
          },
          "o": { "a": 0, "k": 100 }
        }
        """
        let anim = animJSON(masksJSON: maskJSON)

        let package = try createTempPackage(
            sceneJSON: scene,
            animFiles: ["anim-1.json": anim],
            images: ["img_1.png"]
        )
        let loaded = try loader.loadAnimations(from: package)
        let report = customValidator.validate(scene: package.scene, package: package, loaded: loaded)

        // Should have a topology mismatch error for closed flag
        let topologyError = report.errors.first {
            $0.code == AnimValidationCode.pathTopologyMismatch
        }
        XCTAssertNotNil(topologyError, "Closed flag mismatch should produce validation error")
        XCTAssertTrue(topologyError?.message.contains("closed") ?? false, "Error should mention closed flag")
    }

    func testValidate_animatedPathConsistentTopology_noError() throws {
        // Create validator with animated paths allowed
        var options = AnimValidator.Options()
        options.allowAnimatedMaskPath = true
        let customValidator = AnimValidator(options: options)

        let scene = sceneJSON()
        // Valid animated mask with consistent topology (same vertex count and closed flag)
        let maskJSON = """
        {
          "mode": "a",
          "inv": false,
          "pt": {
            "a": 1,
            "k": [
              {
                "t": 0,
                "s": [{ "v": [[0,0], [100,0], [100,100], [0,100]], "i": [[0,0], [0,0], [0,0], [0,0]], "o": [[0,0], [0,0], [0,0], [0,0]], "c": true }]
              },
              {
                "t": 30,
                "s": [{ "v": [[10,10], [90,10], [90,90], [10,90]], "i": [[0,0], [0,0], [0,0], [0,0]], "o": [[0,0], [0,0], [0,0], [0,0]], "c": true }]
              }
            ]
          },
          "o": { "a": 0, "k": 100 }
        }
        """
        let anim = animJSON(masksJSON: maskJSON)

        let package = try createTempPackage(
            sceneJSON: scene,
            animFiles: ["anim-1.json": anim],
            images: ["img_1.png"]
        )
        let loaded = try loader.loadAnimations(from: package)
        let report = customValidator.validate(scene: package.scene, package: package, loaded: loaded)

        // Should NOT have topology errors
        let topologyError = report.errors.first {
            $0.code == AnimValidationCode.pathTopologyMismatch ||
            $0.code == AnimValidationCode.pathKeyframesMissing
        }
        XCTAssertNil(topologyError, "Consistent topology should not produce errors")
    }

    // MARK: - Forbidden Layer Flags Tests

    func testValidate_layer3D_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ddd": 1 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayer3D
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".ddd") ?? false)
    }

    func testValidate_layerAutoOrient_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ao": 1 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerAutoOrient
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".ao") ?? false)
    }

    func testValidate_layerStretch_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "sr": 2 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerStretch
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".sr") ?? false)
        XCTAssertTrue(error?.message.contains("sr=2") ?? false)
    }

    func testValidate_layerCollapseTransform_returnsError() throws {
        // PR-12: ct=1 on NON-matte-source layer should be ERROR
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ct": 1 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        // ct=1 on regular layer (not td=1) should be ERROR
        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNotNil(error, "ct=1 outside matte-source context should produce an error")
        XCTAssertTrue(error?.path.contains(".ct") ?? false)
        XCTAssertTrue(error?.message.contains("outside matte-source context") ?? false)

        // Should NOT be a warning (on regular layers)
        let warning = report.warnings.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNil(warning, "ct=1 outside matte-source context should NOT be a warning")
    }

    func testValidate_blendMode_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "bm": 3 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedBlendMode
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".bm") ?? false)
        XCTAssertTrue(error?.message.contains("bm=3") ?? false)
    }

    func testValidate_normalBlendMode_noError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "bm": 0 }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedBlendMode
        }
        XCTAssertNil(error, "Normal blend mode (bm=0) should be allowed")
    }

    // MARK: - Skew Validation Tests

    func testValidate_skewNonZero_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ks": { "o": { "a": 0, "k": 100 }, "sk": { "a": 0, "k": 15 } } }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedSkew
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".ks.sk.k") ?? false)
        XCTAssertTrue(error?.message.contains("sk=15") ?? false)
    }

    func testValidate_skewAnimated_returnsError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ks": { "o": { "a": 0, "k": 100 }, "sk": { "a": 1, "k": [{"t": 0, "s": [0]}, {"t": 30, "s": [15]}] } } }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedSkew
        }
        XCTAssertNotNil(error)
        XCTAssertTrue(error?.path.contains(".ks.sk.a") ?? false)
    }

    func testValidate_skewZero_noError() throws {
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ks": { "o": { "a": 0, "k": 100 }, "sk": { "a": 0, "k": 0 } } }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedSkew
        }
        XCTAssertNil(error, "Skew sk=0 should be allowed")
    }

    func testValidate_skewUnknownFormat_returnsError() throws {
        // Test fail-fast: unknown format (e.g., object instead of number) should error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0", "ks": { "o": { "a": 0, "k": 100 }, "sk": { "a": 0, "k": {"invalid": "format"} } } }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedSkew
        }
        XCTAssertNotNil(error, "Unknown skew format should produce error (no silent ignore)")
        XCTAssertTrue(error?.path.contains(".ks.sk.k") ?? false)
        XCTAssertTrue(error?.message.contains("unrecognized") ?? false)
    }

    // MARK: - Shape Layer Validation Tests (All ty=4, not just td=1)

    func testValidate_shapeLayerWithTrimPaths_returnsError() throws {
        // Shape layer WITHOUT td=1 (not a matte source) should still be validated
        // PR-13: Uses specific UNSUPPORTED_TRIM_PATHS code instead of generic UNSUPPORTED_SHAPE_ITEM
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "tm", "nm": "Trim Paths" }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedTrimPaths
        }
        XCTAssertNotNil(error, "Shape layer with tm should produce UNSUPPORTED_TRIM_PATHS error")
        XCTAssertTrue(error?.message.contains("Trim Paths") ?? false)
    }

    func testValidate_shapeLayerWithRect_noError() throws {
        // Rectangle (rc) is now supported (PR-07)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "rc", "nm": "Rectangle 1", "p": {"a": 0, "k": [50, 50]}, "s": {"a": 0, "k": [100, 100]}, "r": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem && $0.message.contains("'rc'")
        }
        XCTAssertNil(error, "Rectangle shape should NOT produce unsupportedShapeItem error (supported since PR-07)")
    }

    func testValidate_rectInGroupShape_noError() throws {
        // Rectangle nested inside a group should be allowed
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [{ "ty": "rc", "p": {"a": 0, "k": [0, 0]}, "s": {"a": 0, "k": [50, 50]} }, { "ty": "fl" }, { "ty": "tr" }] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem && $0.message.contains("'rc'")
        }
        XCTAssertNil(error, "Rectangle inside group should NOT produce error (supported since PR-07)")
    }

    func testValidate_rectWithAnimatedRoundness_returnsError() throws {
        // Rectangle with animated roundness should fail (not supported)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "rc", "nm": "Animated Roundness Rect", "p": {"a": 0, "k": [50, 50]}, "s": {"a": 0, "k": [100, 100]}, "r": {"a": 1, "k": [{"t": 0, "s": [0]}, {"t": 30, "s": [20]}]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedRectRoundnessAnimated
        }
        XCTAssertNotNil(error, "Animated rectangle roundness should produce error")
        XCTAssertTrue(error?.path.contains(".r.a") ?? false, "Error path should point to roundness animation flag")
    }

    func testValidate_rectWithMismatchedKeyframeCounts_returnsError() throws {
        // Rectangle with p having 2 keyframes and s having 3 keyframes should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "rc", "nm": "Mismatched Rect", "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]}, "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 5, "s": [150, 150]}, {"t": 10, "s": [200, 200]}]}, "r": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedRectKeyframesMismatch
        }
        XCTAssertNotNil(error, "Rectangle with mismatched keyframe counts should produce error")
        XCTAssertTrue(error?.message.contains("2 keyframes") ?? false, "Error should mention position keyframe count")
        XCTAssertTrue(error?.message.contains("3") ?? false, "Error should mention size keyframe count")
    }

    func testValidate_rectWithMismatchedKeyframeTimes_returnsError() throws {
        // Rectangle with p and s having same count but different times should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "rc", "nm": "Time Mismatch Rect", "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]}, "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 15, "s": [200, 200]}]}, "r": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedRectKeyframesMismatch
        }
        XCTAssertNotNil(error, "Rectangle with mismatched keyframe times should produce error")
        XCTAssertTrue(error?.message.contains("time mismatch") ?? false, "Error should mention time mismatch")
    }

    func testValidate_rectWithMatchingKeyframes_noError() throws {
        // Rectangle with p and s having matching keyframes should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "rc", "nm": "Matching Rect", "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]}, "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 10, "s": [200, 200]}]}, "r": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let keyframeMismatchError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedRectKeyframesMismatch
        }
        let keyframeFormatError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedRectKeyframeFormat
        }
        XCTAssertNil(keyframeMismatchError, "Rectangle with matching keyframes should NOT produce mismatch error")
        XCTAssertNil(keyframeFormatError, "Rectangle with valid keyframes should NOT produce format error")
    }

    func testValidate_rectWithAnimatedPositionInvalidFormat_returnsError() throws {
        // Rectangle with animated position (a=1) but k is not a keyframes array
        // This tests the fail-fast when keyframes can't be decoded
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "rc", "nm": "Invalid Anim Rect", "p": {"a": 1, "k": [50, 50]}, "s": {"a": 0, "k": [100, 100]}, "r": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedRectKeyframeFormat
        }
        XCTAssertNotNil(error, "Rectangle with animated position but invalid keyframes format should produce error")
        XCTAssertTrue(error?.path.contains(".p") ?? false, "Error path should reference position (.p)")
        XCTAssertTrue(error?.message.contains("could not be decoded") ?? false, "Error should mention keyframes could not be decoded")
    }

    // MARK: - Ellipse Shape Validation (PR-08)

    func testValidate_ellipseShape_noError() throws {
        // Ellipse (el) is now supported (PR-08)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "el", "nm": "Ellipse 1", "p": {"a": 0, "k": [50, 50]}, "s": {"a": 0, "k": [100, 100]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem && $0.message.contains("'el'")
        }
        XCTAssertNil(error, "Ellipse shape should NOT produce unsupportedShapeItem error (now supported)")
    }

    func testValidate_ellipseInGroupShape_noError() throws {
        // Ellipse nested inside a group should also pass (now supported)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [{ "ty": "el", "p": {"a": 0, "k": [0, 0]}, "s": {"a": 0, "k": [50, 50]} }, { "ty": "fl" }, { "ty": "tr" }] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem && $0.message.contains("'el'")
        }
        XCTAssertNil(error, "Ellipse inside group should NOT produce unsupportedShapeItem error (now supported)")
    }

    func testValidate_ellipseWithMismatchedKeyframeCounts_returnsError() throws {
        // Ellipse with p having 2 keyframes and s having 3 keyframes - should produce mismatch error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{
                "ty": "el",
                "nm": "Ellipse Mismatch",
                "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]},
                "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 5, "s": [150, 150]}, {"t": 10, "s": [200, 200]}]}
            }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedEllipseKeyframesMismatch
        }
        XCTAssertNotNil(error, "Ellipse with mismatched keyframe counts should produce error")
        XCTAssertTrue(error?.message.contains("2 keyframes") ?? false, "Error should mention position has 2 keyframes")
        XCTAssertTrue(error?.message.contains("3") ?? false, "Error should mention size has 3 keyframes")
    }

    func testValidate_ellipseWithMismatchedKeyframeTimes_returnsError() throws {
        // Ellipse with p and s having different keyframe times - should produce mismatch error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{
                "ty": "el",
                "nm": "Ellipse Time Mismatch",
                "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]},
                "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 15, "s": [200, 200]}]}
            }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedEllipseKeyframesMismatch
        }
        XCTAssertNotNil(error, "Ellipse with mismatched keyframe times should produce error")
        XCTAssertTrue(error?.message.contains("time mismatch") ?? false, "Error should mention time mismatch")
    }

    func testValidate_ellipseAnimatedPositionInvalidFormat_returnsError() throws {
        // Ellipse with animated position (a=1) but k is not a keyframes array
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "el", "nm": "Invalid Anim Ellipse", "p": {"a": 1, "k": [50, 50]}, "s": {"a": 0, "k": [100, 100]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedEllipseKeyframeFormat
        }
        XCTAssertNotNil(error, "Ellipse with animated position but invalid keyframes format should produce error")
        XCTAssertTrue(error?.path.contains(".p") ?? false, "Error path should reference position (.p)")
        XCTAssertTrue(error?.message.contains("could not be decoded") ?? false, "Error should mention keyframes could not be decoded")
    }

    func testValidate_ellipseWithMatchingKeyframes_noError() throws {
        // Ellipse with p and s having matching keyframe count and times - should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{
                "ty": "el",
                "nm": "Ellipse Matching",
                "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]},
                "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 10, "s": [200, 200]}]}
            }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let keyframeMismatchError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedEllipseKeyframesMismatch
        }
        let keyframeFormatError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedEllipseKeyframeFormat
        }
        XCTAssertNil(keyframeMismatchError, "Ellipse with matching keyframes should NOT produce mismatch error")
        XCTAssertNil(keyframeFormatError, "Ellipse with valid keyframes should NOT produce format error")
    }

    func testValidate_ellipseInvalidStaticSize_returnsError() throws {
        // Ellipse with static size that has zero width - should produce invalid size error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "el", "nm": "Zero Width Ellipse", "p": {"a": 0, "k": [50, 50]}, "s": {"a": 0, "k": [0, 100]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedEllipseInvalidSize
        }
        XCTAssertNotNil(error, "Ellipse with zero width should produce invalid size error")
        XCTAssertTrue(error?.message.contains("width=0") ?? false || error?.message.contains("width=0.0") ?? false, "Error should mention width=0")
    }

    // MARK: - Polystar Shape Validation (PR-09)

    func testValidate_polystarShape_noError() throws {
        // Polystar (sr) is now supported (PR-09) - valid polygon should produce no error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 5}, "or": {"a": 0, "k": 50}, "os": {"a": 0, "k": 0}, "r": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem && $0.message.contains("'sr'")
        }
        XCTAssertNil(error, "Polystar shape should NOT produce unsupportedShapeItem error (now supported)")
    }

    func testValidate_polystarInGroupShape_noError() throws {
        // Polystar nested inside a group should also pass (now supported)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 5}, "or": {"a": 0, "k": 50}, "os": {"a": 0, "k": 0} }, { "ty": "fl" }, { "ty": "tr" }] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedShapeItem && $0.message.contains("'sr'")
        }
        XCTAssertNil(error, "Polystar inside group should NOT produce unsupportedShapeItem error (now supported)")
    }

    func testValidate_polystarInvalidStarType_returnsError() throws {
        // Polystar with invalid star type (sy=3) should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 3, "pt": {"a": 0, "k": 5}, "or": {"a": 0, "k": 50} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarStarType
        }
        XCTAssertNotNil(error, "Polystar with invalid star type should produce error")
        XCTAssertTrue(error?.path.contains(".sy") ?? false, "Error path should reference .sy")
    }

    func testValidate_polystarPointsAnimated_returnsError() throws {
        // Polystar with animated points should produce error (topology would change)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 1, "k": [{"t": 0, "s": [5]}, {"t": 10, "s": [8]}]}, "or": {"a": 0, "k": 50}, "os": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarPointsAnimated
        }
        XCTAssertNotNil(error, "Polystar with animated points should produce error")
        XCTAssertTrue(error?.message.contains("Topology") ?? false, "Error should mention topology")
    }

    func testValidate_polystarPointsNonInteger_returnsError() throws {
        // Polystar with non-integer points should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 5.5}, "or": {"a": 0, "k": 50}, "os": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarPointsNonInteger
        }
        XCTAssertNotNil(error, "Polystar with non-integer points should produce error")
    }

    func testValidate_polystarPointsInvalid_returnsError() throws {
        // Polystar with points < 3 should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 2}, "or": {"a": 0, "k": 50}, "os": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarPointsInvalid
        }
        XCTAssertNotNil(error, "Polystar with points < 3 should produce error")
    }

    func testValidate_polystarRoundnessAnimated_returnsError() throws {
        // Polystar with animated roundness should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 5}, "or": {"a": 0, "k": 50}, "os": {"a": 1, "k": [{"t": 0, "s": [0]}, {"t": 10, "s": [50]}]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarRoundnessAnimated
        }
        XCTAssertNotNil(error, "Polystar with animated roundness should produce error")
    }

    func testValidate_polystarRoundnessNonzero_returnsError() throws {
        // Polystar with non-zero roundness should produce error (not supported in PR-09)
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 5}, "or": {"a": 0, "k": 50}, "os": {"a": 0, "k": 25} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarRoundnessNonzero
        }
        XCTAssertNotNil(error, "Polystar with non-zero roundness should produce error")
    }

    func testValidate_polystarInvalidOuterRadius_returnsError() throws {
        // Polystar with or <= 0 should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "sr", "sy": 2, "pt": {"a": 0, "k": 5}, "or": {"a": 0, "k": 0}, "os": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarInvalidRadius
        }
        XCTAssertNotNil(error, "Polystar with or=0 should produce error")
        XCTAssertTrue(error?.path.contains(".or") ?? false, "Error path should reference .or")
    }

    func testValidate_polystarMismatchedKeyframeCounts_returnsError() throws {
        // Polystar with p having 2 keyframes and or having 3 keyframes should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{
                "ty": "sr", "sy": 2,
                "pt": {"a": 0, "k": 5},
                "or": {"a": 1, "k": [{"t": 0, "s": [50]}, {"t": 5, "s": [75]}, {"t": 10, "s": [100]}]},
                "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]},
                "os": {"a": 0, "k": 0}
            }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarKeyframesMismatch
        }
        XCTAssertNotNil(error, "Polystar with mismatched keyframe counts should produce error")
    }

    func testValidate_polystarMismatchedKeyframeTimes_returnsError() throws {
        // Polystar with p and or having different keyframe times should produce error
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{
                "ty": "sr", "sy": 2,
                "pt": {"a": 0, "k": 5},
                "or": {"a": 1, "k": [{"t": 0, "s": [50]}, {"t": 15, "s": [100]}]},
                "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]},
                "os": {"a": 0, "k": 0}
            }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarKeyframesMismatch
        }
        XCTAssertNotNil(error, "Polystar with mismatched keyframe times should produce error")
    }

    func testValidate_polystarMatchingKeyframes_noError() throws {
        // Polystar with matching keyframes should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{
                "ty": "sr", "sy": 2,
                "pt": {"a": 0, "k": 5},
                "or": {"a": 1, "k": [{"t": 0, "s": [50]}, {"t": 10, "s": [100]}]},
                "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 10, "s": [50, 50]}]},
                "os": {"a": 0, "k": 0}
            }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let keyframeMismatchError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarKeyframesMismatch
        }
        let keyframeFormatError = report.errors.first {
            $0.code == AnimValidationCode.unsupportedPolystarKeyframeFormat
        }
        XCTAssertNil(keyframeMismatchError, "Polystar with matching keyframes should NOT produce mismatch error")
        XCTAssertNil(keyframeFormatError, "Polystar with valid keyframes should NOT produce format error")
    }

    // MARK: - Stroke Shape Validation (PR-10)

    func testValidate_strokeShape_noError() throws {
        // Valid stroke with static color, opacity, and width should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "o": {"a": 0, "k": 100}, "w": {"a": 0, "k": 5}, "lc": 2, "lj": 2, "ml": 4 }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let strokeError = report.errors.first {
            $0.code.hasPrefix("UNSUPPORTED_STROKE")
        }
        XCTAssertNil(strokeError, "Valid stroke should NOT produce stroke error")
    }

    func testValidate_strokeInGroupShape_noError() throws {
        // Stroke nested inside a group should also pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 2}, "lc": 1, "lj": 1, "ml": 10 }, { "ty": "sh" }, { "ty": "tr" }] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let strokeError = report.errors.first {
            $0.code.hasPrefix("UNSUPPORTED_STROKE")
        }
        XCTAssertNil(strokeError, "Valid stroke in group should NOT produce error")
    }

    func testValidate_strokeWithDash_returnsError() throws {
        // Stroke with dash pattern should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 5}, "d": [{"n": "d", "v": {"a": 0, "k": 10}}] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeDash }
        XCTAssertNotNil(error, "Stroke with dash should produce UNSUPPORTED_STROKE_DASH error")
    }

    func testValidate_strokeColorAnimated_returnsError() throws {
        // Stroke with animated color should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 1, "k": [{"t": 0, "s": [1, 0, 0]}]}, "w": {"a": 0, "k": 5} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeColorAnimated }
        XCTAssertNotNil(error, "Stroke with animated color should produce UNSUPPORTED_STROKE_COLOR_ANIMATED error")
    }

    func testValidate_strokeOpacityAnimated_returnsError() throws {
        // Stroke with animated opacity should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "o": {"a": 1, "k": [{"t": 0, "s": [100]}]}, "w": {"a": 0, "k": 5} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeOpacityAnimated }
        XCTAssertNotNil(error, "Stroke with animated opacity should produce UNSUPPORTED_STROKE_OPACITY_ANIMATED error")
    }

    func testValidate_strokeWidthMissing_returnsError() throws {
        // Stroke without width should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeWidthMissing }
        XCTAssertNotNil(error, "Stroke without width should produce UNSUPPORTED_STROKE_WIDTH_MISSING error")
    }

    func testValidate_strokeWidthZero_returnsError() throws {
        // Stroke with width=0 should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 0} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeWidthInvalid }
        XCTAssertNotNil(error, "Stroke with width=0 should produce UNSUPPORTED_STROKE_WIDTH_INVALID error")
    }

    func testValidate_strokeWidthExceedsMax_returnsError() throws {
        // Stroke with width > 2048 should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 3000} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeWidthInvalid }
        XCTAssertNotNil(error, "Stroke with width > 2048 should produce UNSUPPORTED_STROKE_WIDTH_INVALID error")
    }

    func testValidate_strokeInvalidLinecap_returnsError() throws {
        // Stroke with invalid lineCap should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 5}, "lc": 99 }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeLinecap }
        XCTAssertNotNil(error, "Stroke with invalid lineCap should produce UNSUPPORTED_STROKE_LINECAP error")
    }

    func testValidate_strokeInvalidLinejoin_returnsError() throws {
        // Stroke with invalid lineJoin should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 5}, "lj": 0 }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeLinejoin }
        XCTAssertNotNil(error, "Stroke with invalid lineJoin should produce UNSUPPORTED_STROKE_LINEJOIN error")
    }

    func testValidate_strokeInvalidMiterlimit_returnsError() throws {
        // Stroke with miterLimit <= 0 should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 0, "k": 5}, "ml": -1 }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeMiterlimit }
        XCTAssertNotNil(error, "Stroke with invalid miterLimit should produce UNSUPPORTED_STROKE_MITERLIMIT error")
    }

    func testValidate_strokeAnimatedWidth_noError() throws {
        // Stroke with animated width and valid keyframes should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 1, "k": [{"t": 0, "s": [5]}, {"t": 30, "s": [10]}]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let strokeError = report.errors.first { $0.code.hasPrefix("UNSUPPORTED_STROKE") }
        XCTAssertNil(strokeError, "Stroke with valid animated width should NOT produce error")
    }

    func testValidate_strokeAnimatedWidthInvalidKeyframe_returnsError() throws {
        // Stroke with animated width but invalid keyframe value should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 1, "k": [{"t": 0, "s": [5]}, {"t": 30, "s": [3000]}]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeWidthInvalid }
        XCTAssertNotNil(error, "Stroke with keyframe width > 2048 should produce UNSUPPORTED_STROKE_WIDTH_INVALID error")
    }

    func testValidate_strokeAnimatedWidthMissingTime_returnsError() throws {
        // Stroke with animated width but keyframe missing time should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 1, "k": [{"s": [5]}, {"t": 30, "s": [10]}]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeWidthKeyframeFormat }
        XCTAssertNotNil(error, "Stroke with keyframe missing time should produce UNSUPPORTED_STROKE_WIDTH_KEYFRAME_FORMAT error")
    }

    func testValidate_strokeAnimatedWidthMissingStartValue_returnsError() throws {
        // Stroke with animated width but keyframe missing startValue should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "st", "c": {"a": 0, "k": [1, 0, 0]}, "w": {"a": 1, "k": [{"t": 0}, {"t": 30, "s": [10]}]} }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedStrokeWidthKeyframeFormat }
        XCTAssertNotNil(error, "Stroke with keyframe missing startValue should produce UNSUPPORTED_STROKE_WIDTH_KEYFRAME_FORMAT error")
    }

    // MARK: - Group Transform Validation Tests (PR-11)

    func testValidate_groupTransformStatic_noError() throws {
        // Group with static transform should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "fl", "c": {"a": 0, "k": [1, 0, 0]} },
              { "ty": "tr", "p": {"a": 0, "k": [100, 100]}, "a": {"a": 0, "k": [0, 0]}, "s": {"a": 0, "k": [100, 100]}, "r": {"a": 0, "k": 45}, "o": {"a": 0, "k": 100} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let groupTransformError = report.errors.first { $0.code.hasPrefix("UNSUPPORTED_GROUP_TRANSFORM") }
        XCTAssertNil(groupTransformError, "Valid static group transform should NOT produce error")
    }

    func testValidate_groupTransformAnimated_noError() throws {
        // Group with animated transform (uniform scale) should pass
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "fl", "c": {"a": 0, "k": [1, 0, 0]} },
              { "ty": "tr", "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 30, "s": [100, 100]}]}, "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 30, "s": [200, 200]}]}, "r": {"a": 1, "k": [{"t": 0, "s": [0]}, {"t": 30, "s": [90]}]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let groupTransformError = report.errors.first { $0.code.hasPrefix("UNSUPPORTED_GROUP_TRANSFORM") }
        XCTAssertNil(groupTransformError, "Valid animated group transform should NOT produce error")
    }

    func testValidate_groupTransformMultiple_returnsError() throws {
        // Group with multiple tr items should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "p": {"a": 0, "k": [0, 0]} },
              { "ty": "tr", "p": {"a": 0, "k": [50, 50]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformMultiple }
        XCTAssertNotNil(error, "Group with multiple transforms should produce UNSUPPORTED_GROUP_TRANSFORM_MULTIPLE error")
    }

    func testValidate_groupTransformSkew_returnsError() throws {
        // Group with skew should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "p": {"a": 0, "k": [0, 0]}, "sk": {"a": 0, "k": 15} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformSkew }
        XCTAssertNotNil(error, "Group with skew should produce UNSUPPORTED_GROUP_TRANSFORM_SKEW error")
    }

    func testValidate_groupTransformNonUniformScale_returnsError() throws {
        // Group with non-uniform scale (sx != sy) should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "p": {"a": 0, "k": [0, 0]}, "s": {"a": 0, "k": [150, 100]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformScaleNonuniform }
        XCTAssertNotNil(error, "Group with non-uniform scale should produce UNSUPPORTED_GROUP_TRANSFORM_SCALE_NONUNIFORM error")
    }

    func testValidate_groupTransformNonUniformScaleAnimated_returnsError() throws {
        // Group with animated non-uniform scale should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "s": {"a": 1, "k": [{"t": 0, "s": [100, 100]}, {"t": 30, "s": [200, 150]}]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformScaleNonuniform }
        XCTAssertNotNil(error, "Group with animated non-uniform scale should produce UNSUPPORTED_GROUP_TRANSFORM_SCALE_NONUNIFORM error")
    }

    func testValidate_groupTransformKeyframesMismatch_returnsError() throws {
        // Group with mismatched keyframe counts should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "p": {"a": 1, "k": [{"t": 0, "s": [0, 0]}, {"t": 30, "s": [100, 100]}]}, "r": {"a": 1, "k": [{"t": 0, "s": [0]}, {"t": 15, "s": [45]}, {"t": 30, "s": [90]}]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformKeyframesMismatch }
        XCTAssertNotNil(error, "Group with mismatched keyframe counts should produce UNSUPPORTED_GROUP_TRANSFORM_KEYFRAMES_MISMATCH error")
    }

    func testValidate_groupTransformKeyframeMissingTime_returnsError() throws {
        // Group with keyframe missing time should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "p": {"a": 1, "k": [{"s": [0, 0]}, {"t": 30, "s": [100, 100]}]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformKeyframeFormat }
        XCTAssertNotNil(error, "Group with keyframe missing time should produce UNSUPPORTED_GROUP_TRANSFORM_KEYFRAME_FORMAT error")
    }

    func testValidate_groupTransformKeyframeMissingStartValue_returnsError() throws {
        // Group with keyframe missing startValue should fail
        let scene = sceneJSON()
        let anim = """
        {
          "fr": 30, "ip": 0, "op": 300, "w": 1080, "h": 1920,
          "assets": [
            { "id": "image_0", "u": "images/", "p": "img_1.png" },
            { "id": "comp_0", "layers": [{ "ty": 2, "nm": "media", "refId": "image_0" }] }
          ],
          "layers": [
            { "ty": 0, "refId": "comp_0" },
            { "ty": 4, "shapes": [{ "ty": "gr", "it": [
              { "ty": "sh" },
              { "ty": "tr", "r": {"a": 1, "k": [{"t": 0}, {"t": 30, "s": [90]}]} }
            ] }] }
          ]
        }
        """
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let error = report.errors.first { $0.code == AnimValidationCode.unsupportedGroupTransformKeyframeFormat }
        XCTAssertNotNil(error, "Group with keyframe missing startValue should produce UNSUPPORTED_GROUP_TRANSFORM_KEYFRAME_FORMAT error")
    }

    // MARK: - Integration Tests

    func testValidate_validMask_noError() throws {
        let scene = sceneJSON()
        let maskJSON = """
        { "mode": "a", "inv": false, "pt": { "a": 0, "k": {} }, "o": { "a": 0, "k": 100 } }
        """
        let anim = animJSON(masksJSON: maskJSON)
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let maskErrors = report.errors.filter {
            $0.code.hasPrefix("UNSUPPORTED_MASK")
        }
        XCTAssertEqual(maskErrors.count, 0)
    }

    func testValidate_bindingInPrecomp_found() throws {
        let scene = sceneJSON(bindingKey: "media")
        let anim = animJSON(bindingLayerName: "media")
        let report = try validatePackage(sceneJSON: scene, animJSON: anim)

        let bindingError = report.errors.first {
            $0.code == AnimValidationCode.bindingLayerNotFound
        }
        XCTAssertNil(bindingError)
    }

    // MARK: - PR-01 Negative Asset Tests (Bundle.module)

    /// Helper to load and validate a negative test case from Bundle.module
    /// Uses a scene with mediaBlock referencing the anim.json so it gets validated
    private func validateNegativeCase(_ caseName: String) throws -> ValidationReport {
        guard let animURL = Bundle.module.url(
            forResource: "anim",
            withExtension: "json",
            subdirectory: "Resources/negative/\(caseName)"
        ) else {
            XCTFail("Could not find anim.json for negative case: \(caseName)")
            throw NSError(domain: "TestError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Missing test asset"])
        }

        let animData = try Data(contentsOf: animURL)
        let animJSONString = String(data: animData, encoding: .utf8)!

        // Create scene with a media block that references our anim.json
        // Use a placeholder binding key that may or may not exist in the anim
        let sceneWithBlock = """
        {
          "schemaVersion": "0.1",
          "canvas": { "width": 1080, "height": 1920, "fps": 30, "durationFrames": 90 },
          "mediaBlocks": [{
            "blockId": "test_block",
            "zIndex": 0,
            "rect": { "x": 0, "y": 0, "width": 1080, "height": 1920 },
            "containerClip": "slotRect",
            "input": {
              "rect": { "x": 0, "y": 0, "width": 1080, "height": 1920 },
              "bindingKey": "_test_placeholder_",
              "allowedMedia": ["photo"]
            },
            "variants": [{ "variantId": "v1", "animRef": "anim.json" }]
          }]
        }
        """

        tempDir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

        let sceneURL = tempDir.appendingPathComponent("scene.json")
        try sceneWithBlock.write(to: sceneURL, atomically: true, encoding: .utf8)

        let animFileURL = tempDir.appendingPathComponent("anim.json")
        try animJSONString.write(to: animFileURL, atomically: true, encoding: .utf8)

        let package = try packageLoader.load(from: tempDir)
        let loaded = try loader.loadAnimations(from: package)

        return validator.validate(scene: package.scene, package: package, loaded: loaded)
    }

    // MARK: - PR-13: Trim Paths Tests

    func testNegativeAsset_trimPathsInGroup_returnsErrorWithCorrectPath() throws {
        // tm inside group should produce UNSUPPORTED_TRIM_PATHS error with correct nested path
        let report = try validateNegativeCase("neg_trim_paths_tm")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedTrimPaths
        }
        XCTAssertNotNil(error, "neg_trim_paths_tm should produce UNSUPPORTED_TRIM_PATHS error")

        // Verify path points to the exact location: layers[0].shapes[0].it[2].ty
        // (tm is at index 2 inside the group's items array)
        XCTAssertTrue(error?.path.contains(".shapes[0].it[2].ty") == true,
                      "Path should point to .shapes[0].it[2].ty, got: \(error?.path ?? "nil")")

        // Verify message mentions Trim Paths
        XCTAssertTrue(error?.message.contains("Trim Paths") == true,
                      "Message should mention Trim Paths")
    }

    func testNegativeAsset_trimPathsTopLevel_returnsErrorWithCorrectPath() throws {
        // tm at top level of shapes array should produce UNSUPPORTED_TRIM_PATHS error
        let report = try validateNegativeCase("neg_trim_paths_top_level")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedTrimPaths
        }
        XCTAssertNotNil(error, "neg_trim_paths_top_level should produce UNSUPPORTED_TRIM_PATHS error")

        // Verify path points to the exact location: layers[0].shapes[0].ty
        XCTAssertTrue(error?.path.contains(".shapes[0].ty") == true,
                      "Path should point to .shapes[0].ty, got: \(error?.path ?? "nil")")

        // Verify it does NOT contain .it (not nested in group)
        XCTAssertFalse(error?.path.contains(".it[") == true,
                       "Path should NOT contain .it[] for top-level tm")
    }

    func testNegativeAsset_maskExpansion_returnsUnsupportedMaskExpansionNonZero() throws {
        let report = try validateNegativeCase("neg_mask_expansion_x")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskExpansionNonZero
        }
        XCTAssertNotNil(error, "neg_mask_expansion_x should produce UNSUPPORTED_MASK_EXPANSION_NONZERO error")
    }

    func testNegativeAsset_maskOpacityAnimated_returnsUnsupportedMaskOpacityAnimated() throws {
        let report = try validateNegativeCase("neg_mask_opacity_animated")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMaskOpacityAnimated
        }
        XCTAssertNotNil(error, "neg_mask_opacity_animated should produce UNSUPPORTED_MASK_OPACITY_ANIMATED error")
    }

    func testNegativeAsset_skewNonZero_returnsUnsupportedSkew() throws {
        let report = try validateNegativeCase("neg_skew_sk_nonzero")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedSkew
        }
        XCTAssertNotNil(error, "neg_skew_sk_nonzero should produce UNSUPPORTED_SKEW error")
    }

    func testNegativeAsset_layer3D_returnsUnsupportedLayer3D() throws {
        let report = try validateNegativeCase("neg_layer_ddd_3d")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayer3D
        }
        XCTAssertNotNil(error, "neg_layer_ddd_3d should produce UNSUPPORTED_LAYER_3D error")
    }

    func testNegativeAsset_autoOrient_returnsUnsupportedLayerAutoOrient() throws {
        let report = try validateNegativeCase("neg_layer_ao_auto_orient")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerAutoOrient
        }
        XCTAssertNotNil(error, "neg_layer_ao_auto_orient should produce UNSUPPORTED_LAYER_AUTO_ORIENT error")
    }

    func testNegativeAsset_stretch_returnsUnsupportedLayerStretch() throws {
        let report = try validateNegativeCase("neg_layer_sr_stretch")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerStretch
        }
        XCTAssertNotNil(error, "neg_layer_sr_stretch should produce UNSUPPORTED_LAYER_STRETCH error")
    }

    // MARK: - PR-12: ct Context-Aware Severity Tests

    func testNegativeAsset_collapseTransform_onRegularLayer_returnsError() throws {
        // ct=1 on a regular layer (not td=1, not in matte-source precomp) should be ERROR (PR-12)
        let report = try validateNegativeCase("neg_layer_ct_collapse_transform")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNotNil(error, "ct=1 outside matte-source context should produce ERROR")
        XCTAssertTrue(error?.message.contains("outside matte-source context") == true)

        // Should NOT be a warning (outside matte-source context)
        let warning = report.warnings.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNil(warning, "ct=1 outside matte-source context should NOT be warning")
    }

    func testNegativeAsset_collapseTransform_onMatteSource_returnsWarning() throws {
        // ct=1 on matte source (td=1) should be WARNING (PR-12)
        let report = try validateNegativeCase("neg_layer_ct_on_matte_source")

        let warning = report.warnings.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNotNil(warning, "ct=1 on matte source (td=1) should produce WARNING")
        XCTAssertTrue(warning?.message.contains("matte-source context") == true)

        // Should NOT be an error (on matte source layers)
        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNil(error, "ct=1 on matte source should NOT be error")
    }

    func testNegativeAsset_collapseTransform_inMatteSourcePrecomp_returnsWarning() throws {
        // ct=1 inside a matte-source precomp should be WARNING (PR-12 fix)
        let report = try validateNegativeCase("neg_layer_ct_in_matte_precomp")

        let warning = report.warnings.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNotNil(warning, "ct=1 inside matte-source precomp should produce WARNING")
        XCTAssertTrue(warning?.path.contains("assets[id=comp_matte]") == true)
        XCTAssertTrue(warning?.message.contains("matte-source context") == true)

        // Should NOT be an error (in matte-source context)
        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNil(error, "ct=1 inside matte-source precomp should NOT be error")
    }

    func testNegativeAsset_collapseTransform_inRegularPrecomp_returnsError() throws {
        // ct=1 inside a regular precomp (not matte source) should be ERROR (PR-12)
        let report = try validateNegativeCase("neg_layer_ct_in_regular_precomp")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNotNil(error, "ct=1 inside regular precomp should produce ERROR")
        XCTAssertTrue(error?.path.contains("assets[id=comp_regular]") == true)
        XCTAssertTrue(error?.message.contains("outside matte-source context") == true)

        // Should NOT be a warning (not in matte-source context)
        let warning = report.warnings.first {
            $0.code == AnimValidationCode.unsupportedLayerCollapseTransform
        }
        XCTAssertNil(warning, "ct=1 inside regular precomp should NOT be warning")
    }

    // MARK: - PR-12: Matte Pair Validation Tests

    func testNegativeAsset_matteConsumerNoSource_returnsError() throws {
        // Matte consumer (tt=1) at index 0 has no source above it
        let report = try validateNegativeCase("neg_matte_consumer_no_source")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMatteLayerMissing
        }
        XCTAssertNotNil(error, "Matte consumer at index 0 should produce UNSUPPORTED_MATTE_LAYER_MISSING")
        XCTAssertTrue(error?.path.contains("[0].tt") == true)
    }

    func testNegativeAsset_matteConsumerWrongOrder_returnsError() throws {
        // Matte consumer (tt=1) with previous layer not being td=1
        let report = try validateNegativeCase("neg_matte_consumer_wrong_order")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMatteLayerOrder
        }
        XCTAssertNotNil(error, "Matte consumer with non-td=1 previous layer should produce UNSUPPORTED_MATTE_LAYER_ORDER")
        XCTAssertTrue(error?.path.contains("[0].td") == true)
    }

    func testNegativeAsset_matteSourceIsConsumer_returnsError() throws {
        // Matte source (td=1) that is also a consumer (has tt) is invalid
        let report = try validateNegativeCase("neg_matte_source_is_consumer")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedMatteSourceHasConsumer
        }
        XCTAssertNotNil(error, "Matte source with tt should produce UNSUPPORTED_MATTE_SOURCE_HAS_CONSUMER")
        XCTAssertTrue(error?.path.contains(".td") == true)
    }

    func testNegativeAsset_blendMode_returnsUnsupportedBlendMode() throws {
        let report = try validateNegativeCase("neg_layer_bm_blend_mode")

        let error = report.errors.first {
            $0.code == AnimValidationCode.unsupportedBlendMode
        }
        XCTAssertNotNil(error, "neg_layer_bm_blend_mode should produce UNSUPPORTED_BLEND_MODE error")
    }
}
